namespace ElixirControlPlatform.API.Shared.Domain.Repositories;

public interface IUnitOfWOrk
{
    Task CompleteAsync();
}